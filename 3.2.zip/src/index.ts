import { of } from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import { switchMap, catchError } from 'rxjs/operators';

const directors = fromFetch('http://localhost:3000/directors').pipe(
  switchMap(response => {
    if (response.ok) {
      return response.json();
    } else {
      return of({ error: true, message: `Error: ${response.status}` })
    }
  })
);

directors.subscribe(val => console.log({val}));
