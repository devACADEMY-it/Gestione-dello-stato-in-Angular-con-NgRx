import { of } from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import { switchMap, catchError } from 'rxjs/operators';

const data = document.querySelector('#data');

const createList = (items: any[]) => {
  const ul = document.createElement('ul');

  items.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = JSON.stringify(item);
    ul.appendChild(li);
  });

  data.appendChild(ul);
};

const directors = fromFetch('http://localhost:3000/directors').pipe(
  switchMap(response => {
    if (response.ok) {
      return response.json();
    } else {
      return of({ error: true, message: `Error: ${response.status}` })
    }
  })
);

directors.subscribe(val => createList(val));
