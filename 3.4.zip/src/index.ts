import { of } from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import {switchMap, catchError, flatMap, concatMap, map} from 'rxjs/operators';

const ENDPOINT = {
  directors: 'http://localhost:3000/directors',
  movies: 'http://localhost:3000/movies',
  reviews: 'http://localhost:3000/reviews'
};

const data = document.querySelector('#data');

const createList = (items: any[]) => {
  const ul = document.createElement('ul');

  items.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = JSON.stringify(item);
    ul.appendChild(li);
  });

  data.appendChild(ul);
};

const fetchUrl = (url: string) => {
  return fromFetch(url).pipe(
    flatMap(response => response.json())
  )
};

const obs = of(ENDPOINT.directors).pipe(
  concatMap(url => fetchUrl(url)),
  flatMap(directors => {
    createList(directors);
    return directors;
  }),
  map((director: any) => fetchUrl(`${ENDPOINT.movies}?directorId=${director.id}`)),
  flatMap(movies => movies)
);

obs.subscribe(val => createList(val));
