import {combineLatest, of} from 'rxjs';
import { fromFetch } from 'rxjs/fetch';
import {switchMap, catchError, flatMap, concatMap, map} from 'rxjs/operators';
import {RxHR} from '@akanass/rx-http-request';

const ENDPOINT = {
  directors: 'http://localhost:3000/directors',
  movies: 'http://localhost:3000/movies',
  reviews: 'http://localhost:3000/reviews'
};

// Elenco registi
const director$ = RxHR.get(ENDPOINT.directors, {json: true}).pipe(
  map(response => response.body)
);

// Find dell'id di Stanley Kubrick
const directorId$ = director$.pipe(
  map(directors => directors.find((director: any) => director.name === 'Stanley Kubrick').id)
);

// Tutti i film di Kubrick
const directorMovies$ = directorId$.pipe(
  flatMap(id => {
    return RxHR.get(`${ENDPOINT.movies}?directorId=${id}`, {json: true})
  }),
  map(response => response.body[0].items)
);

const getAverageRating = (movie: any) => {
  return RxHR.get(`${ENDPOINT.reviews}?movieId=${movie.id}`, {json: true}).pipe(
    map(response => {
      const items: any = response.body[0].items;
      return items.reduce((acc: number, curr: any) => acc + curr.rating, 0) / items.length;
    }),
    map(averageRating => ({ title: movie.title, averageRating }))
  )
};

// Prelevare i ratings
const movieRatings$ = directorMovies$.pipe(
  flatMap(movies => {
    const observables$: any[] = [];
    movies.forEach((movie: any) => observables$.push(getAverageRating(movie)));
    return combineLatest(observables$);
  })
);

const best$ = movieRatings$.pipe(
  map(movies => movies.sort((a: any, b: any) => b.averageRating - a.averageRating)[0])
);

best$.subscribe((bestMovie: any) =>
  console.log(`Il miglior film di Stanley Kubrick è ${bestMovie.title} con voto ${bestMovie.averageRating}`));
