import {createAction} from '@ngrx/store';

const ACTION_TYPE = {
  INCREMENT: 'INCREMENT',
  DECREMENT: 'DECREMENT',
  RESET: 'RESET'
};

export const increment = createAction(ACTION_TYPE.INCREMENT);
export const decrement = createAction(ACTION_TYPE.DECREMENT);
export const reset = createAction(ACTION_TYPE.RESET);
