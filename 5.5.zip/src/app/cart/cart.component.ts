import { Component, OnInit } from '@angular/core';
import {Cart, CartProduct} from '../models/cart.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart;

  constructor() {
    this.cart = {
      products: [
        {
          id: 2,
          name: 'coke',
          quantity: 1,
          imageSrc: 'coca.png',
          price: 2
        },
        {
          id: 6,
          name: 'hamburger',
          quantity: 2,
          imageSrc: 'hamburger.png',
          price: 8
        },
      ],
      price: 18,
    };
  }

  ngOnInit(): void {
  }

  getImageSrc(product: CartProduct): string {
    return `assets/${product.imageSrc}`;
  }

}
