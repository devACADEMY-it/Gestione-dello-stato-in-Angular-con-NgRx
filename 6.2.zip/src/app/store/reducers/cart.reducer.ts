import {Cart, CartProduct} from '../../models/cart.model';
import * as CartActions from '../actions/cart.actions';
import {Action, createReducer, on} from '@ngrx/store';

export interface CartState {
  cart: Cart;
}

export const initialState: CartState = {
  cart: {
    products: [],
    total: 0,
  }
};

const _cartReducer = createReducer(initialState,
  on(CartActions.addProduct, (state, { product }) => {
    const newProducts = [...state.cart.products];
    const find = state.cart.products.find(item => item.id === product.id);
    if (find) {
      find.quantity += 1;
    } else {
      const toAdd: CartProduct = {
        id: product.id,
        name: product.name,
        imageSrc: product.imageSrc,
        price: product.price,
        quantity: 1,
      };
      newProducts.push(toAdd);
    }
    return {
      ...state,
      cart: {
        ...state.cart,
        products: newProducts,
      }
    };
  })
);

export function reducer(state: CartState | undefined, action: Action) {
  return _cartReducer(state, action);
}
