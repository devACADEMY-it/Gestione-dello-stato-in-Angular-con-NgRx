import { Component, OnInit } from '@angular/core';
import {Product} from '../models/product.model';
// @ts-ignore
import { products } from '../data.json';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[];

  constructor() {
    this.products = products;
  }

  ngOnInit(): void {
  }

  onAddToCart(product: Product) {
    console.log({product});
    // ??
  }
}
