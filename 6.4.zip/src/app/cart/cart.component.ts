import { Component, OnInit } from '@angular/core';
import {Cart, CartProduct} from '../models/cart.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart;

  constructor() {
    this.cart = {
      products: [],
      total: 0,
    };
  }

  ngOnInit(): void {
  }

  getImageSrc(product: CartProduct): string {
    return `assets/${product.imageSrc}`;
  }

}
