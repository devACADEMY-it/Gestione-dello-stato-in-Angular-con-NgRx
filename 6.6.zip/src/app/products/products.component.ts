import { Component, OnInit } from '@angular/core';
import {Product} from '../models/product.model';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {addProduct} from '../store/actions/cart.actions';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products$: Observable<Product[]>;

  constructor(private store: Store<{ products: Product[] }>) {
    this.products$ = store.pipe(select('products'));
  }

  ngOnInit(): void {
  }

  onAddToCart(product: Product) {
    this.store.dispatch(addProduct({ product }));
  }
}
