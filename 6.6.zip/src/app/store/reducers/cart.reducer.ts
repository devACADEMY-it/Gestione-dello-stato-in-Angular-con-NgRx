import {Cart, CartProduct} from '../../models/cart.model';
import * as CartActions from '../actions/cart.actions';
import {Action, createReducer, on} from '@ngrx/store';

export const initialState: Cart = {
  products: [],
  total: 0,
};

const _cartReducer = createReducer(initialState,
  on(CartActions.addProduct, (state, { product }) => {
    const newProducts = state.products.map(item => ({ ...item }));
    const findIndex = state.products.findIndex(item => item.id === product.id);
    if (findIndex !== -1) {
      newProducts[findIndex].quantity += 1;
    } else {
      const toAdd: CartProduct = {
        id: product.id,
        name: product.name,
        imageSrc: product.imageSrc,
        price: product.price,
        quantity: 1,
      };
      newProducts.push(toAdd);
    }
    return {
      ...state,
      total: state.total + product.price,
      products: newProducts,
    };
  })
);

export function cartReducer(state: Cart | undefined, action: Action) {
  return _cartReducer(state, action);
}
