import {Product} from '../../models/product.model';
// @ts-ignore
import { products } from '../../data.json';
import {Action, createReducer} from '@ngrx/store';

export const initialState: Product[] = products;

const _productsReducer = createReducer(initialState);

export function productsReducer(state: Product[] | undefined, action: Action) {
  return _productsReducer(state, action);
}
