export interface Product {
  id: number;
  label: string;
  name: string;
  imageSrc: string;
  price: number;
}
