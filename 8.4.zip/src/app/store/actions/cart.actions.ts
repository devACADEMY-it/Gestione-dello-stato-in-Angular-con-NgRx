import {createAction, props} from '@ngrx/store';
import {CartProduct} from '../../models/cart.model';
import {Product} from '../../models/product.model';

const CART_ACTION = {
  BEGIN_ADD: '[CART] BEGIN ADD',
  SUCCESS_ADD: '[CART] SUCCESS ADD',
  ERROR_ADD: '[CART] ERROR ADD',
  REMOVE: '[CART] REMOVE PRODUCT',
};

export const beginAddProduct = createAction(
  CART_ACTION.BEGIN_ADD,
  props<{ product: Product }>(),
);
export const successAddProduct = createAction(
  CART_ACTION.SUCCESS_ADD,
  props<{ result: CartProduct }>()
);
export const errorAddProduct = createAction(
  CART_ACTION.ERROR_ADD,
  props<{ error: Error }>()
);
export const removeProduct = createAction(
  CART_ACTION.REMOVE,
  props<{ name: string }>()
);
