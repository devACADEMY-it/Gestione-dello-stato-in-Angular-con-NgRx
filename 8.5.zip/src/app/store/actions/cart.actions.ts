import {createAction, props} from '@ngrx/store';
import {CartProduct} from '../../models/cart.model';
import {Product} from '../../models/product.model';

const CART_ACTION = {
  BEGIN_ADD: '[CART] BEGIN ADD TO CART',
  SUCCESS_ADD: '[CART] SUCCESS ADD TO CART',
  ERROR_ADD: '[CART] ERROR ADD TO CART',
  REMOVE: '[CART] REMOVE PRODUCT',
};

export const beginAddToCart = createAction(
  CART_ACTION.BEGIN_ADD,
  props<{ product: Product }>(),
);
export const successAddToCart = createAction(
  CART_ACTION.SUCCESS_ADD,
  props<{ result: CartProduct }>()
);
export const errorAddToCart = createAction(
  CART_ACTION.ERROR_ADD,
  props<{ error: Error }>()
);
export const removeProduct = createAction(
  CART_ACTION.REMOVE,
  props<{ name: string }>()
);
