import { Component, OnInit } from '@angular/core';
import {Cart, CartProduct} from '../models/cart.model';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {removeProduct} from '../store/actions/cart.actions';
import {CartState} from '../store/reducers/cart.reducer';
import {map} from 'rxjs/operators';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  observable: Observable<CartState>;
  products: CartProduct[];
  total: number;
  error: boolean;

  constructor(private store: Store<{ cart: CartState }>) {
    this.observable = store.pipe(select('cart'));
    this.products = [];
    this.total = 0;
    this.error = false;
  }

  ngOnInit(): void {
    this.observable.pipe(
      map(cart => {
        this.products = cart.cart.products;
        this.total = cart.cart.total;
        this.error = cart.error;
      })
    ).subscribe();
  }

  getImageSrc(product: CartProduct): string {
    return `assets/${product.imageSrc}`;
  }

  onRemoveItem(product: CartProduct) {
    // this.store.dispatch(removeProduct({ name: product.name }));
  }
}
