import { Component, OnInit } from '@angular/core';
import {Product} from '../models/product.model';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {beginAddToCart} from '../store/actions/cart.actions';
import {ProductState} from '../store/reducers/products.reducer';
import {map} from 'rxjs/operators';
import * as ProductActions from '../store/actions/products.actions';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  observable: Observable<ProductState>;
  products: Product[];
  error: boolean;
  isLoading: boolean;

  constructor(private store: Store<{ warehouse: ProductState }>) {
    this.observable = store.pipe(select('warehouse'));
    this.isLoading = false;
  }

  ngOnInit(): void {
    this.observable.pipe(
      map(warehouse => {
        this.products = warehouse.products;
        this.error = warehouse.error;
      })
    ).subscribe();

    this.store.dispatch(ProductActions.beginGetProducts());
  }

  onAddToCart(product: Product) {
    this.isLoading = true;
    this.store.dispatch(beginAddToCart({ product }));
    this.isLoading = false;
  }
}
