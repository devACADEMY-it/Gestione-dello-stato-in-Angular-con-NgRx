import {Injectable} from '@angular/core';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {HttpClient} from '@angular/common/http';
import {Action} from '@ngrx/store';
import {Observable, of} from 'rxjs';
import * as CartActions from '../actions/cart.actions';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {Product} from '../../models/product.model';
import {CartProduct} from '../../models/cart.model';

@Injectable()
export class CartEffects {
  constructor(private http: HttpClient, private actions: Actions) {}

  private ENDPOINT = 'http://localhost:3000/cart';

  addToCart: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(CartActions.beginAddToCart),
      mergeMap(action => {
        const product = action.product;
        const cartProduct = {
          id: product.id,
          name: product.name,
          quantity: 1,
          imageSrc: product.imageSrc,
          price: product.price,
        };
        return this.http.post(this.ENDPOINT, JSON.stringify(cartProduct), {
          headers: { 'Content-Type': 'application/json' }
        }).pipe(
          map((result: CartProduct) => {
            return CartActions.successAddToCart({ result });
          }),
          catchError((error: Error) => {
            return of(CartActions.errorAddToCart({ error }));
          })
        );
      })
    );
  });
}
