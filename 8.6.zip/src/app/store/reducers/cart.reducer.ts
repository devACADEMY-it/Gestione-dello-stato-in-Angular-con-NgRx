import {Cart} from '../../models/cart.model';
import * as CartActions from '../actions/cart.actions';
import {Action, createReducer, on} from '@ngrx/store';
import {Product} from '../../models/product.model';

export type CartState = {
  cart: Cart,
  toAdd: Product,
  error: boolean,
};

export const initialState: CartState = {
  cart: {
    products: [],
    total: 0,
  },
  toAdd: null,
  error: false,
};

const _cartReducer = createReducer(initialState,
  on(CartActions.beginAddToCart, (state, payload) => {
    return {
      ...state,
      toAdd: payload.product,
    };
  }),
  on(CartActions.successAddToCart, (state, payload) => {
    return {
      ...state,
      cart: {
        ...state.cart,
        total: state.cart.total + payload.result.price,
        products: [...state.cart.products, payload.result],
      },
      error: false,
      toAdd: null,
    };
  }),
  on(CartActions.errorAddToCart, (state, payload) => {
    return {
      ...state,
      error: true,
      toAdd: null,
    };
  })
);

export function cartReducer(state: CartState | undefined, action: Action) {
  return _cartReducer(state, action);
}
