import { Component, OnInit } from '@angular/core';
import {Product} from '../models/product.model';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {beginAddToCart} from '../store/actions/cart.actions';
import {ProductState} from '../store/reducers/products.reducer';
import {map} from 'rxjs/operators';
import * as ProductActions from '../store/actions/products.actions';
import {Cart} from '../models/cart.model';
import {CartState} from '../store/reducers/cart.reducer';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  observable: Observable<ProductState>;
  cart: Cart;
  products: Product[];
  error: boolean;
  isLoading: boolean;

  constructor(private store: Store<{ warehouse: ProductState, cart: CartState }>) {
    this.observable = store.pipe(select('warehouse'));
    this.isLoading = false;
  }

  ngOnInit(): void {
    this.store.pipe(select('cart')).pipe(
      map(cartState => {
        this.cart = cartState.cart;
      })
    ).subscribe();

    this.observable.pipe(
      map(warehouse => {
        this.products = warehouse.products;
        this.error = warehouse.error;
      })
    ).subscribe();

    this.store.dispatch(ProductActions.beginGetProducts());
  }

  onAddToCart(product: Product) {
    this.isLoading = true;
    setTimeout(() => {
      this.store.dispatch(beginAddToCart({ cart: this.cart, product }));
      this.isLoading = false;
    }, 250);
  }
}
