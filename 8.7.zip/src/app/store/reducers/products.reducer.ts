import {Product} from '../../models/product.model';
import * as ProductActions from '../actions/products.actions';
import {Action, createReducer, on} from '@ngrx/store';

export type ProductState = {
  products: Product[],
  error: boolean,
};

export const initialState: ProductState = {
  products: [],
  error: false,
};

const _productsReducer = createReducer(initialState,
  on(ProductActions.beginGetProducts, state => state),
  on(ProductActions.successGetProducts, (state, { results }) => {
    return {
      ...state,
      products: results,
      error: false,
    };
  }),
  on(ProductActions.errorGetProducts, (state, { error: Error }) => {
    return {
      ...state,
      error: true,
    };
  })
);

export function productsReducer(state: ProductState | undefined, action: Action) {
  return _productsReducer(state, action);
}
