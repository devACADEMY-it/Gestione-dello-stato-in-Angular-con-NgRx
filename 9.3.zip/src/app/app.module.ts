import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductListItemComponent } from './product-list-item/product-list-item.component';
import { CartComponent } from './cart/cart.component';
import {cartReducer} from './store/reducers/cart.reducer';
import {productsReducer} from './store/reducers/products.reducer';
import {ProductsEffects} from './store/effects/products.effects';
import {HttpClientModule} from '@angular/common/http';
import {CartEffects} from './store/effects/cart.effects';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    ProductListComponent,
    ProductListItemComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    StoreModule.forRoot({
      cart: cartReducer,
      warehouse: productsReducer,
    }),
    EffectsModule.forRoot([ ProductsEffects, CartEffects ]),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      name: 'Fast Gino Dev Tools',
      features: {
        jump: false,
        skip: false,
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
